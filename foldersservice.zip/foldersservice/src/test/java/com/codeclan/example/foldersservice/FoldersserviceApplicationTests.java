package com.codeclan.example.foldersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoldersserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
