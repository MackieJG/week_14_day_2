package com.codeclan.example.foldersservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoldersserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoldersserviceApplication.class, args);
	}

}
